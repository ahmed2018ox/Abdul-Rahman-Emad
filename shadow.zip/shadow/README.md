# shadow
script helps you The weak people in English
--------------

 -  script need python3 to work , if you dont have python3 type in terminal : apt-get install python3

# HELLOW FRIEND 

1 - download the file :)

2 - unpack him ;)

3 - put the file in your desktop

4 - open new terminal

5 - type cd Desktop/shadow


6 - type python3 gamil.py
